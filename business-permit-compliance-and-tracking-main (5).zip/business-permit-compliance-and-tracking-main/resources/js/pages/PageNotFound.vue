<template>
    <div class="w-full min-h-screen flex justify-center items-center">
        <h1 class="text-xl font-bold">Page not found</h1>
    </div>
</template>