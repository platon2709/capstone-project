<template>
    <div class="w-full min-h-screen flex flex-col justify-center items-center gap-10 py-10">
        <section class="w-full md:w-3/5 rounded-lg shadow-xl p-10 bg-slate-900">
            <header class="text-gray-200">
                <h1 class="text-2xl font-bold">Business Permit Requirements</h1>
            </header>
        </section>
        <section class="w-full md:w-3/5 rounded-lg shadow-xl p-10 bg-slate-900">
            <header class="mb-5 text-gray-200">
                <h1 class="text-xl font-bold">Barangay Clearance</h1>
            </header>
            <div class="w-full h-80 border border-gray-400 block text-gray-400 flex justify-center items-center">
                <img src="/public/asset/images/lgu-logo.jpg" alt="barangay-clearance" class="">
            </div>
        </section>
    </div>
</template>