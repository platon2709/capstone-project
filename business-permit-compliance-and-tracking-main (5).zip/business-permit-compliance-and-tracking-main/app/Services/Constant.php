<?php

namespace App\Services;

class Constant
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }

    public static function barangayList()
    {
        return [
              "A. BONIFACIO",
              "ABAD SANTOS",
              "AGUINALDO",
              "ANTIPOLO",
              "BEGUIN",
              "BENIGNO S. AQUINO (IMELDA)",
              "BICAL",
              "BONGA",
              "BUTAG",
              "CADANDANAN",
              "CALOMAGON",
              "CALPI",
              "COCOK-CABITAN",
              "DAGANAS",
              "DANAO",
              "DOLOS",
              "E. QUIRINO",
              "FABRICA",
              "G. DEL PILAR (TANGA)",
              "GATE",
              "INARARAN",
              "J. GERONA",
              "J.P. LAUREL (PON-OD)",
              "JAMORAWON",
              "LAJONG",
              "LIBERTAD",
              "M. ROXAS",
              "MAGSAYSAY",
              "MANAGANAGA",
              "MARINAB",
              "MONTECALVARIO",
              "N. ROQUE (RIZAL)",
              "NAMO",
              "NASUJE",
              "OBRERO",
              "OSME\u00d1A",
              "OTAVI",
              "PADRE DIAZ",
              "PALALE",
              "QUEZON",
              "R. GERONA",
              "RECTO",
              "SAGRADA",
              "SAN FRANCISCO",
              "SAN ISIDRO",
              "SAN JUAN BAG-O",
              "SAN JUAN DAAN",
              "SAN RAFAEL",
              "SAN RAMON",
              "SAN VICENTE",
              "SANTA REMEDIOS",
              "SANTA TERESITA",
              "SIGAD",
              "SOMAGONGSONG",
              "TAROMATA",
              "ZONE I POB. (BGY. 1- SOUTH ILAWOD)",
              "ZONE II POB. (BGY. 2- WEST ILAWOD)",
              "ZONE III POB. (BGY. 3- EAST ILAWOD)",
              "ZONE IV POB. (BGY. 4- WEST CENTRAL)",
              "ZONE V POB. (BGY. 5-LANIPAN)",
              "ZONE VI POB. (BGY. 6- BAYBAY)",
              "ZONE VII POB. (BGY. 7- IRAYA)",
              "ZONE VIII POB. (BGY. 8- LOYO)"
        ];
    }
}
